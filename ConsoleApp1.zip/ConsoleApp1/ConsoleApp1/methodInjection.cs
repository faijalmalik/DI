﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
   public interface ILogInfo
    {
        public void AddLog();
    }
  public  class methodInjectionText :ILogInfo
    {
        public void AddLog()
        {
            Console.WriteLine("Add log call from methodInjectionText");
        }
    }

    public class methodInjectionXML : ILogInfo
    {
        public void AddLog()
        {
            Console.WriteLine("Add log call from methodInjectionXML");
        }
    }

    public class user
    {
        public void SaveData(ILogInfo logInfo)
        {
            logInfo.AddLog();
        }
        public void deleteData(ILogInfo logInfo)
        {
            logInfo.AddLog();
        }
    }
}
