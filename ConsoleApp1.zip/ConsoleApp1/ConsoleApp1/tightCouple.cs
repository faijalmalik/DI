﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
   
        public class Remote
        {
            private Television Tv { get; set; }
            public Remote()
            {
                Tv = new Television();
            }

            static Remote()
            {
                _remoteController = new Remote();
            }
            static Remote _remoteController;
            public static Remote Control
            {
                get
                {
                    return _remoteController;
                }
            }

            public void RunTv()
            {
                Tv.Start();
            }
        }

        public class Television
        {
            public void Start()
            {

            }
        }
    
}
