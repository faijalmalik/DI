﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    interface IWeapon
    {
        public void Hit(string target)
        {
            Console.WriteLine("hit from interface {0}", target);
        }

        public void sorr(string target)
        {
            Console.WriteLine("sorry  interface {0}", target);
        }

    }
    class Sword : IWeapon
    {
       public void Hit(string target)
        {
            Console.WriteLine("hit from class {0}", target);
        }
        
    }

    class Samurai
    {
        readonly IWeapon _weapon;
        
        public Samurai(IWeapon weapon)
        {
            this._weapon = weapon;
        }
        public void Attack(string target)
        {
            this._weapon.Hit(target);
            this._weapon.sorr(target);
        }
    }
}
