﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{

    public interface IRemote
    {
        void Run();
    }
    public class Television1 : IRemote
    {
        public Television1()
        {

        }

        static Television1()
        {
            _television = new Television();
        }
        private static Television _television;
        public static Television Instance
        {
            get
            {
                return _television;
            }
        }

        public void Run()
        {
            Console.WriteLine("Television is started!");
        }
    }

}
