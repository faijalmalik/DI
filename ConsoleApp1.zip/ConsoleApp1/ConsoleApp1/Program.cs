﻿using Serilog;
using System;
using System.Linq;

namespace ConsoleApp1
{
    public delegate int del(int x, int y);
    public delegate string delThree(int x, string y);

    class Program
    {
        

        public static void Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
              .MinimumLevel.Debug()
              //.WriteTo.Console()
              .WriteTo.File(@"C:\Users\fmalik\source\repos\ConsoleApp1\ConsoleApp1\TextFile1.txt", rollingInterval: RollingInterval.Month)
              .CreateLogger();

            Log.Information("this is testing");

            int a = 10, b = 0;
            try
            {
                Log.Debug("Dividing {A} by {B}", a, b);
                Console.WriteLine(a / b);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "PLease try again");
            }

            Log.CloseAndFlush();
            Console.ReadKey();
            //double compairisionPercantage= wordcompairision("fi i i", "faijal malik tabadul");

            // if(compairisionPercantage > 60)
            // {
            //     Console.WriteLine("60 >");
            // }
            // if(compairisionPercantage < 60)
            // {
            //     Console.WriteLine("60 <");
            // }

        }

        public static double wordcompairision(string a,string b)
        {
            var aWords = a.Split(' ');
            var bWords = b.Split(' ');
            double matches = (double)aWords.Count(x => bWords.Contains(x));
            return (matches / (double)aWords.Count()) * 100;
        }
        public static double Compute(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            // Step 1
            if (n == 0)
            {
                return m;
            }

            if (m == 0)
            {
                return n;
            }

            // Step 2
            for (int i = 0; i <= n; d[i, 0] = i++)
            {
            }

            for (int j = 0; j <= m; d[0, j] = j++)
            {
            }

            // Step 3
            for (int i = 1; i <= n; i++)
            {
                //Step 4
                for (int j = 1; j <= m; j++)
                {
                    // Step 5
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                    // Step 6
                    d[i, j] = Math.Min(
                        Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                        d[i - 1, j - 1] + cost);
                }
            }
            // Step 7
            int match= d[n, m];
            return (1.0 - ((double)match / (double)Math.Max(s.Length, t.Length)));
        }
    }

    //class Program
    //{




    //       public static event del eve;
    //       public static event delThree eveThree;
    //    public static void Main(string[] args)
    //    {



    //         eve += new del(Demo.mul);

    //         Console.WriteLine(eve.Invoke(5,4));


    //        user user = new user();
    //        user.SaveData(new methodInjectionText());
    //        user.SaveData(new methodInjectionXML());


    //        var wapon = new Samurai(new Sword());
    //        wapon.Attack("faijal");
    //        wapon.Attack("malik");


    //        del _del = Demo.add;
    //        _del += Demo.mul;

    //        Delegate [] dArray= _del.GetInvocationList();


    //        foreach (del item in dArray)
    //        {
    //            try
    //            {

    //                Console.WriteLine(item.Invoke(5, 5));
    //            }
    //            catch (Exception ex)
    //            {

    //                Console.WriteLine(ex.Message);
    //            }


    //        }
    //        _del.Invoke(5, 6);
    //        Console.WriteLine(_del(1, 2));
    //        Console.WriteLine(_del(4, 2));

    //        Console.ReadLine();

    //    }
    //}
    public  class Demo
    {
        public static int add(int x,int y)
        {
            throw new Exception("ex");
        }
        public static int mul(int x, int y)
        {
            return x * y;
        }
        public static string mul(int x, string y)
        {
            return x + y;
        }
    }

   
}
